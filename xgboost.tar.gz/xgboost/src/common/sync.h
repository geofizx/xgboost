/*!
 * Copyright 2014 by Contributors
 * \file sync.h
 * \brief the synchronization module of rabit
 *        redirects to rabit header
 * \author Tianqi Chen
 */
#ifndef XGBOOST_COMMON_SYNC_H_
#define XGBOOST_COMMON_SYNC_H_

#include <rabit/rabit.h>

#endif  // XGBOOST_COMMON_SYNC_H_
